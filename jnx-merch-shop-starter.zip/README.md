# JNX Merchandise Shop

Guest checkout merchandise shop for Juris Nexum.

## Current version

- GitHub Pages-ready static website
- No buyer accounts
- Product catalog
- Cart with automatic totals
- Buyer checkout information:
  - Full Name
  - Contact Number
  - Email
  - Program
  - Institution
  - Year Level
  - Section
- InstaPay QR payment display
- Automatically computed amount to pay
- Automatic browser receipt
- Print / Save as PDF receipt

## Next backend phase

Google Apps Script will connect the website to Google Sheets and will be the source of truth for:

- Products
- Inventory
- Orders
- Order items
- Payment verification
- Order status
- Receipt/order number
- Optional Google Drive proof-of-payment storage

The backend must recalculate the order total from the Products sheet rather than trusting the browser.

## Deployment

1. Create a GitHub repository.
2. Upload the project files.
3. Enable GitHub Pages from the repository's Pages settings.
4. Deploy the Google Apps Script as a Web App.
5. Put the Apps Script Web App URL in `js/config.js`.
