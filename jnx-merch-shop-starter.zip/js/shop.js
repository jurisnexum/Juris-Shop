const CART_KEY = "jnx_merch_cart_v1";

// Temporary products. These will later be loaded from Google Sheets through Apps Script.
const PRODUCTS = [
  {
    id: "JNX001",
    name: "JNX Classic Shirt",
    category: "Apparel",
    description: "Official Juris Nexum shirt.",
    price: 250,
    stock: 20,
    image: "assets/jnx-logo.png",
    variants: ["S", "M", "L", "XL"]
  },
  {
    id: "JNX002",
    name: "JNX Tote Bag",
    category: "Bags",
    description: "Juris Nexum tote bag for everyday use.",
    price: 180,
    stock: 20,
    image: "assets/jnx-logo.png",
    variants: ["Free Size"]
  }
];

const peso = n => new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(n);

function getCart() {
  return JSON.parse(localStorage.getItem(CART_KEY) || "[]");
}
function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartCount();
}
function updateCartCount() {
  const count = getCart().reduce((sum, x) => sum + x.quantity, 0);
  const el = document.getElementById("cartCount");
  if (el) el.textContent = count;
}
function addToCart(productId, variant) {
  const product = PRODUCTS.find(p => p.id === productId);
  if (!product) return;
  const cart = getCart();
  const key = `${productId}__${variant}`;
  const existing = cart.find(x => x.key === key);
  if (existing) existing.quantity++;
  else cart.push({ key, productId, name: product.name, price: product.price, variant, quantity: 1 });
  saveCart(cart);
  alert(`${product.name} added to cart.`);
}
function renderProducts(filter = "all") {
  const grid = document.getElementById("productGrid");
  const list = PRODUCTS.filter(p => filter === "all" || p.category === filter);
  grid.innerHTML = "";
  if (!list.length) {
    grid.innerHTML = `<div class="empty">No products available.</div>`;
    return;
  }
  list.forEach(p => {
    const variantOptions = p.variants.map(v => `<option value="${v}">${v}</option>`).join("");
    grid.insertAdjacentHTML("beforeend", `
      <article class="product-card">
        <img class="product-image" src="${p.image}" alt="${p.name}">
        <div class="product-info">
          <h3>${p.name}</h3>
          <p>${p.description}</p>
          <div class="price">${peso(p.price)}</div>
          <div class="stock">${p.stock > 0 ? `${p.stock} in stock` : "Out of stock"}</div>
          <label style="margin-bottom:10px;">
            Size / Variant
            <select id="variant-${p.id}">${variantOptions}</select>
          </label>
          <button class="add-button" ${p.stock <= 0 ? "disabled" : ""} onclick="addToCart('${p.id}', document.getElementById('variant-${p.id}').value)">Add to Cart</button>
        </div>
      </article>
    `);
  });
}
function init() {
  const categories = [...new Set(PRODUCTS.map(p => p.category))];
  const filter = document.getElementById("categoryFilter");
  categories.forEach(c => filter.insertAdjacentHTML("beforeend", `<option value="${c}">${c}</option>`));
  filter.addEventListener("change", e => renderProducts(e.target.value));
  renderProducts();
  updateCartCount();
}
document.addEventListener("DOMContentLoaded", init);
