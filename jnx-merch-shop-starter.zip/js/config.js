// Replace this with your deployed Google Apps Script Web App URL.
// Example: https://script.google.com/macros/s/XXXXXXXX/exec
const API_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE";
