const CART_KEY = "jnx_merch_cart_v1";
const ORDER_KEY = "jnx_merch_last_order_v1";

const PRODUCTS = [
  { id: "JNX001", name: "JNX Classic Shirt", price: 250, stock: 20 },
  { id: "JNX002", name: "JNX Tote Bag", price: 180, stock: 20 }
];

const peso = n => new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(n);
const getCart = () => JSON.parse(localStorage.getItem(CART_KEY) || "[]");
const saveCart = cart => localStorage.setItem(CART_KEY, JSON.stringify(cart));

function total(cart) {
  return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

function renderCart() {
  const cart = getCart();
  const box = document.getElementById("cartItems");
  const totalEl = document.getElementById("cartTotal");
  const paymentTotal = document.getElementById("paymentTotal");

  if (!cart.length) {
    box.innerHTML = `<div class="empty">Your cart is empty.<br><br><a href="index.html">Return to shop</a></div>`;
  } else {
    box.innerHTML = cart.map(item => `
      <div class="cart-row">
        <div class="cart-row-title">${item.name}</div>
        <div class="cart-row-meta">${item.variant} · ${peso(item.price)} each</div>
        <div class="cart-row-bottom">
          <div class="qty-control">
            <button type="button" onclick="changeQty('${item.key}', -1)">−</button>
            <strong>${item.quantity}</strong>
            <button type="button" onclick="changeQty('${item.key}', 1)">+</button>
          </div>
          <strong>${peso(item.price * item.quantity)}</strong>
        </div>
      </div>
    `).join("");
  }

  const amount = total(cart);
  totalEl.textContent = peso(amount);
  paymentTotal.textContent = peso(amount);
}

function changeQty(key, delta) {
  const cart = getCart();
  const item = cart.find(x => x.key === key);
  if (!item) return;
  item.quantity += delta;
  if (item.quantity <= 0) cart.splice(cart.indexOf(item), 1);
  saveCart(cart);
  renderCart();
}

function togglePayment() {
  const method = document.getElementById("paymentMethod").value;
  const panel = document.getElementById("paymentPanel");
  const ref = document.getElementById("paymentReference");
  const proof = document.getElementById("proof");

  panel.classList.toggle("hidden", method !== "InstaPay");
  ref.required = method === "InstaPay";
  proof.required = method === "InstaPay";
}

async function submitOrder(event) {
  event.preventDefault();
  const cart = getCart();
  if (!cart.length) {
    alert("Your cart is empty.");
    return;
  }

  const method = document.getElementById("paymentMethod").value;
  const order = {
    fullName: document.getElementById("fullName").value.trim(),
    contact: document.getElementById("contact").value.trim(),
    email: document.getElementById("email").value.trim(),
    program: document.getElementById("program").value.trim(),
    institution: document.getElementById("institution").value.trim(),
    yearLevel: document.getElementById("yearLevel").value,
    section: document.getElementById("section").value.trim(),
    paymentMethod: method,
    paymentReference: method === "InstaPay" ? document.getElementById("paymentReference").value.trim() : "",
    totalAmount: total(cart),
    items: cart,
    createdAt: new Date().toISOString(),
    status: method === "InstaPay" ? "Pending Payment Verification" : "Pending"
  };

  // Frontend receipt works immediately. Backend submission will be connected next.
  // Do not trust this frontend total for final inventory/payment verification;
  // the Apps Script backend will recalculate from the PRODUCTS sheet.
  localStorage.setItem(ORDER_KEY, JSON.stringify(order));
  localStorage.removeItem(CART_KEY);

  window.location.href = "order.html";
}

document.addEventListener("DOMContentLoaded", () => {
  renderCart();
  document.getElementById("paymentMethod").addEventListener("change", togglePayment);
  document.getElementById("checkoutForm").addEventListener("submit", submitOrder);
});
