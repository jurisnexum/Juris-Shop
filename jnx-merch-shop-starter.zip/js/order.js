const ORDER_KEY = "jnx_merch_last_order_v1";
const peso = n => new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(n);

function makeOrderNumber() {
  const d = new Date();
  const random = Math.floor(10000 + Math.random() * 90000);
  return `JNX-${d.getFullYear()}-${random}`;
}

function renderReceipt() {
  const raw = localStorage.getItem(ORDER_KEY);
  const box = document.getElementById("receiptContent");
  if (!raw) {
    box.innerHTML = `<div class="empty">No recent order was found.</div>`;
    return;
  }

  const order = JSON.parse(raw);
  if (!order.orderNumber) {
    order.orderNumber = makeOrderNumber();
    localStorage.setItem(ORDER_KEY, JSON.stringify(order));
  }

  const itemRows = order.items.map(item => `
    <tr>
      <td>${item.name}<br><small>${item.variant}</small></td>
      <td>${item.quantity}</td>
      <td>${peso(item.price)}</td>
      <td>${peso(item.price * item.quantity)}</td>
    </tr>
  `).join("");

  const date = new Date(order.createdAt).toLocaleString("en-PH", {
    dateStyle: "medium", timeStyle: "short"
  });

  box.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:20px;">
      <div><strong>Order No.</strong><br>${order.orderNumber}</div>
      <div><strong>Date</strong><br>${date}</div>
      <div><strong>Buyer</strong><br>${order.fullName}</div>
      <div><strong>Contact</strong><br>${order.contact}</div>
      <div><strong>Program</strong><br>${order.program}</div>
      <div><strong>Institution</strong><br>${order.institution}</div>
      <div><strong>Year Level</strong><br>${order.yearLevel}</div>
      <div><strong>Section</strong><br>${order.section}</div>
    </div>

    <table class="receipt-table">
      <thead><tr><th>Item</th><th>Qty</th><th>Unit Price</th><th>Amount</th></tr></thead>
      <tbody>${itemRows}</tbody>
    </table>

    <div class="receipt-total">TOTAL: ${peso(order.totalAmount)}</div>

    <div style="margin-top:25px;">
      <strong>Payment Method:</strong> ${order.paymentMethod}<br>
      ${order.paymentReference ? `<strong>Reference:</strong> ${order.paymentReference}<br>` : ""}
      <strong>Status:</strong> <span class="status-badge">${order.status}</span>
    </div>

    <p style="margin-top:30px;text-align:center;color:#6d6875;">
      Thank you for supporting Juris Nexum!
    </p>
  `;
}

document.addEventListener("DOMContentLoaded", renderReceipt);
